package org.example;

public enum CardSuits {
    DIAMONDS, HEARTS, CLUBS, SPADES
    /*
    Diamonds (Бубы / Алмазы)
    Hearts (Черви / Сердца)
    Clubs (Трефы / Клубы)
    Spades (Пики / Лопаты)
     */
}
