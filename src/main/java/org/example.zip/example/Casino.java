package org.example;

import java.util.ArrayList;

public class Casino extends Participant{

    public Casino(String name, ArrayList<Card> hand) {
        super(name, hand);
    }
}
