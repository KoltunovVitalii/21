package org.example;

import java.util.ArrayList;

public class Player extends Participant{

    public Player(String name, ArrayList<Card> hand) {
        super(name, hand);
    }
}
